<html>
    <body>
        
    </body>
    <style>
        body{
            border: 1px solid red;

            width: 100%;
            height: 100%;
        }
        .batas {
            position: absolute;
            border: 1px solid black;
            width: 500px;
            height: 700px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        thead>tr>th,tbody>tr>td{
            border: 1px solid black;
            /* display: flex; */
            align-items: center;
            text-align: centerl;
        }
        .tno{
            width: 20%;
        }
        .tnama{
            width: 20%;
        }
        .tsAwal{
            width: 10%;
        }
        .tsoldOnline{
            width: 10%;
        }
        .tsoldOnlineOffline{
            width: 10%;
        }
        .tsisa{
            width: 10%;
        }

    </style>
</html>




