<div class="sidebar">
<nav>
    <h1><a href="/">Jelajah Kuliner</a></h1>

    <hr>
    <a class="btn" href="/login" role="button">Login</a>
    <a class="btn" href="/account/create" role="button">Register</a>
    <a class="btn btn-primary" href="/userguide" role="button">userguide</a>
    <!-- iki lapo kok warning -->
</nav>
    <div class="menu" >
        <p>≡</p>
    </div>
</div>

<script>

    
</script>
