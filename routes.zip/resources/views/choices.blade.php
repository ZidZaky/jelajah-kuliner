@extends('layouts.layout')

@section('title')
    REGISTRASI || JELAJAHKULINER
@endsection

@section('css')
@endsection

@section('main')
<div class="card text-center" style="max-width: 80%; padding-left:20%;">
  <div class="card-header">
    Featured
  </div>
  <div class="card-body">
    <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="/register-customer" class="btn btn-primary">PEMBELI</a>
    <a href="/register-pkl" class="btn btn-primary">PKL</a>
  </div>
  <div class="card-footer text-muted">
    2 days ago
  </div>
</div>
@endsection
