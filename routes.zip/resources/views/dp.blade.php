@extends('layouts.dp')
@section('apa')
  filter("{{$apa}}")
@endsection